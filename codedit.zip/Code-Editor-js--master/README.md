**Editor for free use**
![Dark Theme](https://github.com/us3re/Code-Editor-js-/blob/master/shots/dark.jpg)
![Monokii Theme](https://github.com/us3re/Code-Editor-js-/blob/master/shots/monkia.jpg)
![LightTheme](https://github.com/us3re/Code-Editor-js-/blob/master/shots/light.jpg)

If you want to use this editor online, go to: https://html.technologydev.repl.co
